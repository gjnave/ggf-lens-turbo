from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

MODEL_ID = "WaveCut/Lens-Turbo-SDNQ-uint4-static"
LENS_GIT_URL = "https://github.com/microsoft/Lens.git"
LENS_ZIP_URL = "https://github.com/microsoft/Lens/archive/refs/heads/main.zip"
ENV_NAME = ".lens_turbo_u4"


def root_dir() -> Path:
    return Path(__file__).resolve().parents[2]


def log(msg: str) -> None:
    print(msg, flush=True)


def run(cmd, cwd: Path | None = None, env: dict | None = None, check: bool = True) -> int:
    printable = " ".join(str(x) for x in cmd)
    log(f"\n>> {printable}")
    p = subprocess.run([str(x) for x in cmd], cwd=str(cwd) if cwd else None, env=env)
    if check and p.returncode != 0:
        raise RuntimeError(f"Command failed with exit code {p.returncode}: {printable}")
    return p.returncode


def which(name: str) -> str | None:
    return shutil.which(name)


def find_conda() -> str | None:
    candidates = []
    conda_exe = os.environ.get("CONDA_EXE")
    if conda_exe:
        candidates.append(conda_exe)
    found = which("conda")
    if found:
        candidates.append(found)

    user = Path.home()
    candidates.extend([
        user / "miniconda3" / "Scripts" / "conda.exe",
        user / "anaconda3" / "Scripts" / "conda.exe",
        Path("C:/ProgramData/miniconda3/Scripts/conda.exe"),
        Path("C:/ProgramData/anaconda3/Scripts/conda.exe"),
        Path("C:/Miniconda3/Scripts/conda.exe"),
        Path("C:/Anaconda3/Scripts/conda.exe"),
    ])

    for c in candidates:
        p = Path(c)
        if p.exists():
            return str(p)
    return None


def env_python(env_dir: Path) -> Path:
    p1 = env_dir / "python.exe"
    p2 = env_dir / "Scripts" / "python.exe"
    if p1.exists():
        return p1
    return p2


def create_env(root: Path, force: bool = False) -> Path:
    env_dir = root / "environments" / ENV_NAME
    py = env_python(env_dir)
    if force and env_dir.exists():
        log(f"Removing existing env: {env_dir}")
        shutil.rmtree(env_dir)
    if py.exists():
        log(f"Using existing env: {env_dir}")
        return py

    conda = find_conda()
    if not conda:
        raise RuntimeError(
            "Conda was not found. Install Miniconda/Anaconda or run from a shell where conda is available. "
            "This installer intentionally uses conda so the Python version is controlled and portable."
        )

    env_dir.parent.mkdir(parents=True, exist_ok=True)
    run([conda, "create", "-y", "-p", env_dir, "python=3.11", "pip"])
    py = env_python(env_dir)
    if not py.exists():
        raise RuntimeError(f"Python was not created at expected env path: {py}")
    return py


def pip_install(py: Path, args: list[str], check: bool = True) -> int:
    return run([py, "-m", "pip", "install", *args], check=check)


def install_python_packages(py: Path, allow_sdnq_fail: bool = False) -> None:
    run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])

    log("\nInstalling PyTorch CUDA 12.8 build from the official cu128 index...")
    pip_install(py, [
        "--upgrade",
        "torch>=2.8.0",
        "torchvision",
        "torchaudio",
        "--index-url",
        "https://download.pytorch.org/whl/cu128",
    ])

    log("\nInstalling Lens/Diffusers dependencies...")
    pip_install(py, [
        "--upgrade",
        "diffusers>=0.35.1",
        "transformers>=4.57.1",
        "accelerate",
        "safetensors",
        "huggingface_hub[hf_xet]",
        "sentencepiece",
        "protobuf",
        "pillow",
        "numpy",
        "scipy",
        "einops",
        "peft",
        "tqdm",
    ])

    log("\nInstalling SDNQ package for UINT4 model support...")
    rc = pip_install(py, ["--upgrade", "sdnq"], check=False)
    if rc != 0:
        msg = (
            "sdnq failed to install. This model will probably not load without SDNQ support. "
            "The rest of the environment is still useful for checking Lens/LensPipeline."
        )
        if allow_sdnq_fail:
            log("WARNING: " + msg)
        else:
            raise RuntimeError(msg)


def download_lens_repo(root: Path, force_repo: bool = False) -> Path:
    repo_dir = root / "models" / "lens" / "repos" / "Lens"
    if force_repo and repo_dir.exists():
        log(f"Removing existing Lens repo: {repo_dir}")
        shutil.rmtree(repo_dir)
    if (repo_dir / "lens").exists():
        log(f"Using existing Lens repo: {repo_dir}")
        return repo_dir

    repo_dir.parent.mkdir(parents=True, exist_ok=True)
    git = which("git")
    if git:
        run([git, "clone", "--depth", "1", LENS_GIT_URL, repo_dir])
        return repo_dir

    log("Git was not found; downloading Lens repo ZIP instead...")
    tmp = root / "temp" / "lens_repo_main.zip"
    tmp.parent.mkdir(parents=True, exist_ok=True)
    urllib.request.urlretrieve(LENS_ZIP_URL, tmp)
    extract_root = root / "temp" / "lens_repo_extract"
    if extract_root.exists():
        shutil.rmtree(extract_root)
    extract_root.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(tmp, "r") as zf:
        zf.extractall(extract_root)
    src = extract_root / "Lens-main"
    if not src.exists():
        raise RuntimeError("Downloaded Lens ZIP did not contain expected Lens-main folder.")
    if repo_dir.exists():
        shutil.rmtree(repo_dir)
    shutil.move(str(src), str(repo_dir))
    shutil.rmtree(extract_root, ignore_errors=True)
    return repo_dir


def verify(py: Path, root: Path, repo_dir: Path) -> None:
    code = rf'''
import os, sys, json
sys.path.insert(0, r"{repo_dir}")
import torch
print("torch", torch.__version__)
print("cuda_available", torch.cuda.is_available())
print("torch_cuda", torch.version.cuda)
if torch.cuda.is_available():
    print("gpu", torch.cuda.get_device_name(0))
try:
    import sdnq
    print("sdnq import", "ok")
except Exception as e:
    print("sdnq import failed", repr(e))
    raise
from lens import LensPipeline
print("LensPipeline import", "ok")
'''
    run([py, "-c", code])


def maybe_snapshot_model(py: Path, root: Path) -> None:
    target = root / "models" / "lens" / "hf_cache"
    target.mkdir(parents=True, exist_ok=True)
    code = rf'''
from huggingface_hub import snapshot_download
print("Downloading/snapshotting model: {MODEL_ID}")
path = snapshot_download(repo_id="{MODEL_ID}", cache_dir=r"{target}")
print("snapshot", path)
'''
    run([py, "-c", code])


def write_env_info(root: Path, py: Path, repo_dir: Path) -> None:
    logs = root / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    info = logs / "lens_turbo_u4_install_info.txt"
    info.write_text(
        "Lens Turbo SDNQ UINT4 installer\n"
        f"installed_at={time.strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"root={root}\n"
        f"env_python={py}\n"
        f"lens_repo={repo_dir}\n"
        f"model_id={MODEL_ID}\n",
        encoding="utf-8",
    )
    log(f"Wrote install info: {info}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Install standalone Lens Turbo SDNQ UINT4 test environment.")
    parser.add_argument("--force-env", action="store_true", help="Delete and recreate the conda env.")
    parser.add_argument("--force-repo", action="store_true", help="Delete and redownload the Microsoft Lens repo.")
    parser.add_argument("--download-model", action="store_true", help="Snapshot the Hugging Face model during install.")
    parser.add_argument("--allow-sdnq-fail", action="store_true", help="Continue if pip install sdnq fails.")
    args = parser.parse_args()

    root = root_dir()
    log(f"Root: {root}")
    (root / "models" / "lens").mkdir(parents=True, exist_ok=True)
    (root / "output" / "lens_turbo_u4").mkdir(parents=True, exist_ok=True)
    (root / "temp").mkdir(parents=True, exist_ok=True)

    py = create_env(root, force=args.force_env)
    install_python_packages(py, allow_sdnq_fail=args.allow_sdnq_fail)
    repo_dir = download_lens_repo(root, force_repo=args.force_repo)
    verify(py, root, repo_dir)
    if args.download_model:
        maybe_snapshot_model(py, root)
    write_env_info(root, py, repo_dir)

    log("\nDONE")
    log("Run run_lens_test.bat to try a small image generation test.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print("\nERROR:", exc, file=sys.stderr)
        raise SystemExit(1)
